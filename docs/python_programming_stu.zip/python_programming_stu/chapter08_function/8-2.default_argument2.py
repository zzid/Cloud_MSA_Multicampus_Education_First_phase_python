def daily_sleeping_hours(hours=7):
    return hours

print(daily_sleeping_hours(10))

print(daily_sleeping_hours())