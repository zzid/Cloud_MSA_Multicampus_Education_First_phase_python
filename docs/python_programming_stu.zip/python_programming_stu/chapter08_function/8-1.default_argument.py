def daily_sleeping_hours(hours):
    return hours

print(daily_sleeping_hours(10))

print(daily_sleeping_hours())