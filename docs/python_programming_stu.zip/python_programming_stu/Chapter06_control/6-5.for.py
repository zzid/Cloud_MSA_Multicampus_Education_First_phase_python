# for 문 예시 #######################

signals = 'blue', 'yellow', 'red'    # 3가지 색에 대한 튜플 생성

for signal in signals:                 # for 문 실행
    print(signal, len(signal))          # 튜플의 값, 길이 출력
