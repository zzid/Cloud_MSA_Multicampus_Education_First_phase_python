# 구구단 전체 출력 ##############

for m in range(1, 10):
    print('='*10)
    for n in range(1, 10):
        print(m, 'x', n, '=', m*n)
