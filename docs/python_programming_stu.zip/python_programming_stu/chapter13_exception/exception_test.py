def exception():
    print("[1] Can you add 2 and '2' in python?")
    print("[2] Try it~!", 2+'2')
    print("[3] It's not possible to add integer and string together")


exception()