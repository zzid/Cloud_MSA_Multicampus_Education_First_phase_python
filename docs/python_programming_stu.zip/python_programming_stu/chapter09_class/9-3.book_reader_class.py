class BookReader:
    country = 'South Korea'

print(BookReader.country )
BookReader.country = 'USA'
print(BookReader.country )

